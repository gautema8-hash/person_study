const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DOInrYRY.js","./index-DTO3_VLS.js","./index-ClZsn08p.css"])))=>i.map(i=>d[i]);
import{r as e,_ as o}from"./index-DTO3_VLS.js";const _=e("Toast",{web:()=>o(()=>import("./web-DOInrYRY.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(t=>new t.ToastWeb)});export{_ as Toast};
