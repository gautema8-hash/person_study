const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-G_XH-MO0.js","./index-DTO3_VLS.js","./index-ClZsn08p.css"])))=>i.map(i=>d[i]);
import{r,_ as p}from"./index-DTO3_VLS.js";const o=r("App",{web:()=>p(()=>import("./web-G_XH-MO0.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.AppWeb)});export{o as App};
